import boto3
import json
import logging
import time
import urllib.parse
from decimal import Decimal
from json import JSONEncoder

class DecimalEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    logger.info("Received event: %s", json.dumps(event, indent=2))

    # Parse the URL-encoded body
    parsed_body = urllib.parse.parse_qs(event['body'])

    # Extract and convert all fields
    try:
        lat = Decimal(parsed_body.get('lat', [None])[0]) if parsed_body.get('lat') else None
        lon = Decimal(parsed_body.get('lon', [None])[0]) if parsed_body.get('lon') else None
        alt = Decimal(parsed_body.get('alt', [None])[0]) if parsed_body.get('alt') else None
        acc = Decimal(parsed_body.get('acc', [None])[0]) if parsed_body.get('acc') else None
        bat = Decimal(parsed_body.get('bat', [None])[0]) if parsed_body.get('bat') else None
        sat = int(parsed_body.get('sat', [None])[0]) if parsed_body.get('sat') else None
        speed = Decimal(parsed_body.get('speed', [None])[0]) if parsed_body.get('speed') else None
        bearing = Decimal(parsed_body.get('bearing', [None])[0]) if parsed_body.get('bearing') else None
        useragent = parsed_body.get('useragent', [None])[0]
        timestamp = str(parsed_body.get('timestamp', [None])[0])
    except (ValueError, TypeError) as e:
        logger.error("Invalid data types in payload: %s", e)
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid data types in payload'})
        }

    if not all([lat, lon, timestamp]):
        logger.error("Missing required fields (lat, lon, timestamp) in the event")
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Missing required fields'})
        }

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('genericDataTable')

    # Calculate TTL (3 hours from now)
    ttl = int(time.time()) + 10800  # three hours

    # Construct the item with all fields
    item = {
        'timestamp': timestamp,
        'lat': lat,
        'lon': lon,
        'alt': alt,
        'acc': acc,
        'bat': bat,
        'sat': sat,
        'speed': speed,
        'bearing': bearing,
        'useragent': useragent,
        'ttl': ttl
    }

    # Remove any None values from the item
    item = {k: v for k, v in item.items() if v is not None}

    # Format the output after constructing the item
    def format_output(item):
        formatted_item = {
            'Time': item['timestamp'],
            'Latitude': f"{item['lat']:.6f}" if item.get('lat') is not None else 'N/A',
            'Longitude': f"{item['lon']:.6f}" if item.get('lon') is not None else 'N/A',
            'Altitude': f"{item['alt']:.2f} meters" if item.get('alt') is not None else 'N/A',
            'Accuracy': f"{item['acc']:.2f} meters" if item.get('acc') is not None else 'N/A',
            'Battery': f"{int(item['bat'])}%" if item.get('bat') is not None else 'N/A',
            'Satellites': item.get('sat', 'N/A'),
            'User Agent': item.get('useragent', 'N/A'),
            'Speed': f"{item['speed']:.2f} km/h" if item.get('speed') is not None else 'N/A',
            'Bearing': f"{item['bearing']:.2f}°" if item.get('bearing') is not None else 'N/A'
        }
        return formatted_item

    formatted_item = format_output(item)
    output_string = "\n".join([f"{key}: {value}" for key, value in formatted_item.items()])

# ... [previous code] ...

    try:
        table.put_item(Item=item)
        logger.info("Logged payload: %s", json.dumps(item, cls=DecimalEncoder))
    except Exception as e:
        logger.error("Error putting item in DynamoDB: %s", e)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Error putting item in DynamoDB'})
        }

    # Include the formatted output in the response
    return {
        'statusCode': 200,
        'headers': {'Access-Control-Allow-Origin': '*'},
        'body': json.dumps({
            'message': 'Payload logged successfully!',
            'formattedOutput': output_string  # Including the formatted output string
        })
    }

