import os
import boto3
import requests
import json

DYNAMODB_TABLE_NAME = os.environ.get("DYNAMODB_TABLE_NAME")
FITBIT_CLIENT_ID = os.environ.get("FITBIT_CLIENT_ID")
FITBIT_CLIENT_SECRET = os.environ.get("FITBIT_CLIENT_SECRET")

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(DYNAMODB_TABLE_NAME)

def lambda_handler(event, context):
    # Retrieve the Fitbit refresh token from DynamoDB
    user_id = "YOUR_USER_ID"  # Replace with the user's identifier
    response = table.get_item(Key={"user_id": user_id})

    if "Item" in response:
        refresh_token = response["Item"]["refresh_token"]
    else:
        raise Exception("Refresh token not found in DynamoDB for the user")

    # Use the refresh token to obtain a new access token
    token_url = "https://api.fitbit.com/oauth2/token"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    }
    auth = (FITBIT_CLIENT_ID, FITBIT_CLIENT_SECRET)

    response = requests.post(token_url, headers=headers, data=data, auth=auth)

    if response.status_code == 200:
        token_data = response.json()
        access_token = token_data["access_token"]
        new_refresh_token = token_data["refresh_token"]

        # Store the new refresh token in DynamoDB
        table.update_item(
            Key={"user_id": user_id},
            UpdateExpression="SET refresh_token = :new_refresh_token",
            ExpressionAttributeValues={":new_refresh_token": new_refresh_token},
        )

        # Use the access token to make Fitbit API requests
        # Add your Fitbit API requests here

        return {"statusCode": 200, "body": "Token refreshed successfully"}
    else:
        raise Exception("Failed to refresh token")
